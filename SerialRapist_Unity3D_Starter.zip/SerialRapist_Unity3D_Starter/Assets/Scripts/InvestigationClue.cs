using UnityEngine;

/// <summary>
/// Safe investigation interaction example: place this on clue objects.
/// Assign a clue label in the Inspector; call Inspect() from an interaction UI.
/// </summary>
public class InvestigationClue : MonoBehaviour
{
    [SerializeField] private string clueId = "clue_01";
    [SerializeField] private string clueDescription = "A piece of evidence";

    public string ClueId => clueId;
    public string ClueDescription => clueDescription;

    public void Inspect()
    {
        Debug.Log($"Evidence discovered: {clueId} — {clueDescription}");
    }
}
