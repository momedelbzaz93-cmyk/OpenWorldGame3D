# ربط السكريبتات بسرعة

## اللاعب
- أنشئ Capsule باسم `Player`.
- أضف `CharacterController`.
- أضف `ThirdPersonController`.
- اضبط Center تقريباً (0, 1, 0) و Height تقريباً 2.
- لا تضف Rigidbody إلى اللاعب مع هذا السكريبت.

## الكاميرا
- أضف `SimpleCameraFollow` إلى Main Camera.
- اسحب Player إلى خانة Target.
- اسحب Main Camera إلى خانة Camera Transform في سكريبت اللاعب.

## الحفظ
- أنشئ Empty GameObject باسم `GameSystems`.
- أضف `GameProgress`.
- يمكن استدعاء `SetCheckpoint(1)` و `CompleteCurrentMission()` من أزرار أو أحداث اللعبة.

## أدلة التحقيق
- أضف `InvestigationClue` إلى مجسم الدليل.
- اكتب الوصف والمعرّف من Inspector.
- عند تفاعل اللاعب مع الدليل، استدعِ `Inspect()`.
