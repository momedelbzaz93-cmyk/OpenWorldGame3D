using UnityEngine;

/// <summary>Simple camera follow. Assign the player Transform to target.</summary>
public class SimpleCameraFollow : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private Vector3 offset = new Vector3(0f, 4f, -6f);
    [SerializeField] private float smoothSpeed = 8f;
    [SerializeField] private bool lookAtTarget = true;

    private void LateUpdate()
    {
        if (target == null) return;

        Vector3 desiredPosition = target.position + target.TransformDirection(offset);
        transform.position = Vector3.Lerp(
            transform.position, desiredPosition, smoothSpeed * Time.deltaTime
        );

        if (lookAtTarget)
        {
            Vector3 lookPoint = target.position + Vector3.up * 1.4f;
            transform.rotation = Quaternion.Slerp(
                transform.rotation,
                Quaternion.LookRotation(lookPoint - transform.position),
                smoothSpeed * Time.deltaTime
            );
        }
    }

    public void SetTarget(Transform value) => target = value;
}
