using UnityEngine;

/// <summary>Minimal local save/load example using PlayerPrefs.</summary>
public class GameProgress : MonoBehaviour
{
    private const string CheckpointKey = "checkpoint_id";
    private const string MissionKey = "mission_index";

    public int CurrentCheckpoint { get; private set; }
    public int CurrentMission { get; private set; }

    private void Start() => LoadProgress();

    public void SaveProgress()
    {
        PlayerPrefs.SetInt(CheckpointKey, CurrentCheckpoint);
        PlayerPrefs.SetInt(MissionKey, CurrentMission);
        PlayerPrefs.Save();
    }

    public void LoadProgress()
    {
        CurrentCheckpoint = PlayerPrefs.GetInt(CheckpointKey, 0);
        CurrentMission = PlayerPrefs.GetInt(MissionKey, 0);
    }

    public void SetCheckpoint(int checkpointId)
    {
        CurrentCheckpoint = Mathf.Max(0, checkpointId);
        SaveProgress();
    }

    public void CompleteCurrentMission()
    {
        CurrentMission++;
        SaveProgress();
    }

    public void ResetProgress()
    {
        PlayerPrefs.DeleteKey(CheckpointKey);
        PlayerPrefs.DeleteKey(MissionKey);
        LoadProgress();
    }
}
