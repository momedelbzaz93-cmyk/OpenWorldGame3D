using UnityEngine;

/// <summary>
/// Basic third-person movement starter.
/// PC: WASD/arrow keys + Space. Mobile UI can call SetMobileMove and RequestJump.
/// Add a CharacterController component to the player GameObject.
/// </summary>
[RequireComponent(typeof(CharacterController))]
public class ThirdPersonController : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] private float moveSpeed = 4.5f;
    [SerializeField] private float rotationSpeed = 12f;
    [SerializeField] private float jumpHeight = 1.2f;
    [SerializeField] private float gravity = -20f;
    [SerializeField] private Transform cameraTransform;

    private CharacterController controller;
    private Vector2 mobileMove;
    private float verticalVelocity;
    private bool mobileJumpRequested;

    private void Awake()
    {
        controller = GetComponent<CharacterController>();
        if (Camera.main != null && cameraTransform == null)
            cameraTransform = Camera.main.transform;
    }

    private void Update()
    {
        Vector2 input = mobileMove;

#if UNITY_EDITOR || UNITY_STANDALONE
        Vector2 keyboard = new Vector2(
            Input.GetAxisRaw("Horizontal"),
            Input.GetAxisRaw("Vertical")
        );
        if (keyboard.sqrMagnitude > input.sqrMagnitude)
            input = Vector2.ClampMagnitude(keyboard, 1f);

        if (Input.GetButtonDown("Jump"))
            mobileJumpRequested = true;
#endif

        Vector3 forward = cameraTransform != null
            ? Vector3.ProjectOnPlane(cameraTransform.forward, Vector3.up).normalized
            : Vector3.forward;
        Vector3 right = cameraTransform != null
            ? Vector3.ProjectOnPlane(cameraTransform.right, Vector3.up).normalized
            : Vector3.right;

        Vector3 direction = Vector3.ClampMagnitude(
            forward * input.y + right * input.x, 1f
        );

        if (direction.sqrMagnitude > 0.001f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(direction);
            transform.rotation = Quaternion.Slerp(
                transform.rotation, targetRotation, rotationSpeed * Time.deltaTime
            );
        }

        if (controller.isGrounded && verticalVelocity < 0f)
            verticalVelocity = -2f;

        if (mobileJumpRequested && controller.isGrounded)
            verticalVelocity = Mathf.Sqrt(jumpHeight * -2f * gravity);

        mobileJumpRequested = false;
        verticalVelocity += gravity * Time.deltaTime;

        Vector3 velocity = direction * moveSpeed;
        velocity.y = verticalVelocity;
        controller.Move(velocity * Time.deltaTime);
    }

    // Connect a mobile joystick's normalized X/Y values to this method.
    public void SetMobileMove(Vector2 value)
    {
        mobileMove = Vector2.ClampMagnitude(value, 1f);
    }

    // Connect a mobile UI Button's OnClick event to this method.
    public void RequestJump()
    {
        mobileJumpRequested = true;
    }
}
