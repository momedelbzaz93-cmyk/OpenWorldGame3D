# SERIAL RAPIST — Unity 3D Starter (Android + PC)

هذه حزمة بداية للمشروع وليست لعبة مكتملة أو APK جاهزاً. موضوع اللعبة جريمة ورعب نفسي خيالي؛ يركز أسلوب اللعب على التحقيق والاستكشاف والمطاردات والنجاة، ولا يتضمن تنفيذ اعتداءات جنسية أو تعليمات لإيذاء أشخاص.

## المتطلبات
- Unity 6 أو Unity 2022.3 LTS
- Android Build Support (Android SDK & NDK + OpenJDK) لتصدير APK
- Git و GitHub Desktop أو Git من سطر الأوامر

## إنشاء مشروع Unity
1. افتح Unity Hub وأنشئ مشروعاً جديداً من قالب **3D (Core)**.
2. سمّه `SerialRapist` (يمكن تغيير الاسم لاحقاً).
3. انسخ مجلد `Assets/Scripts` من هذه الحزمة إلى مجلد المشروع.
4. افتح المشهد الرئيسي واحفظه باسم `MainScene`.
5. أنشئ أرضية (Plane)، وأضف Capsule للشخصية، ثم أضف مكوّن `CharacterController` للشخصية.
6. أضف `ThirdPersonController` و `SimpleCameraFollow` وفق التعليمات أدناه.
7. اربط `SimpleCameraFollow.target` بالشخصية.
8. أضف `GameProgress` إلى كائن فارغ باسم `GameSystems`.

## التحكم
- PC: الأسهم أو WASD للحركة، و Space للقفز.
- Android: أزرار الواجهة يمكنها استدعاء `SetMobileMove(x, y)` و `RequestJump()` على `ThirdPersonController`. أنشئ عصا تحكم UI لاحقاً واربط قيمها بهذه الدوال.

## GitHub
أنشئ مستودعاً فارغاً باسم `SerialRapist-Unity3D`، ثم من مجلد مشروع Unity:
```bash
git init
git add .
git commit -m "Initial Unity 3D project"
git branch -M main
git remote add origin https://github.com/USERNAME/SerialRapist-Unity3D.git
git push -u origin main
```
استبدل `USERNAME` باسم حسابك في GitHub. لا ترفع مجلدات `Library`, `Temp`, `Obj`, `Build` أو بيانات الاعتماد.

## بناء Android
1. من Unity Hub ثبّت Android Build Support مع SDK/NDK و OpenJDK.
2. في Unity افتح `File > Build Profiles` (أو `Build Settings` في الإصدارات الأقدم).
3. اختر Android ثم Switch Platform.
4. أضف المشهد إلى قائمة Scenes، واضبط Package Name مثل `com.yourstudio.serialrapist`.
5. اختر ARM64، ثم Build لإنشاء APK.
6. اختبر على هاتف Android حقيقي.

## الخطوة التالية
أضف نموذج شخصية مرخصاً، مدينة صغيرة تجريبية، نظام مهام تحقيق، ونظام مطاردة غير عنيف. لا تستخدم صوراً أو أصواتاً أو نماذج لا تملك حق استخدامها.
